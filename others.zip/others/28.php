<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "periodtable";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
/* @var $fname type */

$sql = "SELECT Name,Atomicno,RAM,Symbol FROM element WHERE Atomicno='28'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	echo "<table>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
    echo "<b><tr> <td>".$row["Atomicno"]."</td>
	               <td> </td>
				  
	     </tr>
	
	     <tr> <td></td>
		      <h1><td>".$row["Symbol"]." </td></h1>
			  <td></td>
		</tr>
		<tr> <td></td>
		      <h3> <td>".$row["RAM"]."</td></h3>
			  <td></td>
		</tr>
		<tr> <td></td>
		     <h2> <td>".$row["Name"]." </td></h2>
			  <td></td>
		</tr>
		</b>
		";
		
		
	
    }
	echo "</table>";
}else {
     echo "0 results";
}
$conn->close();

?>
